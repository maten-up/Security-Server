# Security-Server

Defensive Discord moderation bot combining JavaScript (Node.js and discord.js) with Python local incident reporting.

## Features
- Rolling-window spam, repeated messages, mention floods, optional Discord invite blocking and administrator-defined hostname blocklist.
- Join-surge and new-account indicators (alerts only, not automatic punishment).
- Observe-only default. Optional enforcement deletes flagged messages and applies a 60-second timeout for flood patterns when permissions allow.
- Moderator and configured-role exemptions, bounded counters, rate-limited alerts, rotating local JSONL logs without message content or member IDs. Moderator-only Discord alerts can include a member ID.
- Private `/security-status` and `/security-report` commands for users with Manage Server permission.

## Install
1. Install Node.js 22.12+ and Python 3.10+.
2. Run `npm install` from the repository directory. When upgrading the old repository, remove its empty `package-lock.json` and `packagelock.json` placeholders first; npm will generate a valid lockfile.
3. Copy `.env.example` to `.env` (`Copy-Item .env.example .env` in PowerShell). Fill in `DISCORD_TOKEN`, `GUILD_ID`, `LOG_CHANNEL_ID`. Set `PYTHON_BIN=python` on Windows if needed.
4. Create your bot in https://discord.com/developers/applications. Enable Server Members and Message Content privileged intents, subject to Discord approval requirements. Install in your own test guild with bot and applications.commands scopes.
5. Grant View Channel, Send Messages, Embed Links and Read Message History. For enforcement add Manage Messages and Moderate Members. Do not grant Administrator. The bot role must be above moderated roles. Restrict the log channel to moderators.
6. Run `npm start`. Test in observe mode, tune thresholds and exemptions, then optionally switch to MODE=enforce and restart.

## Tests
`npm test`, `node --check maten.js`, and `python -m unittest discover -s python`. CI workflow runs these tests. Live Discord integration requires a token and test guild; it has not been validated in this package.

## Limitations
Single guild/process. Heuristic detection only; this is not a complete anti-phishing, anti-raid, malware scanner or network firewall. No external URL fetching. No automatic bans. Alerts can be throttled and log events can be dropped under load. Local logs rotate at approximately 5 MiB, retaining one previous file. Use Discord native AutoMod and role permissions alongside this project. Do not publish credentials or private logs. Rotate any exposed secrets.

## Contributions
Open issues or pull requests with synthetic reproducible test cases, not real tokens or private messages. See SECURITY.md. The repository owner should explicitly select a license before inviting open-source reuse.
