# Security policy

Use only on Discord servers you administer or are authorized to moderate. Report vulnerabilities privately to the maintainer or through GitHub private vulnerability reporting if enabled. Include affected version, impact and reproduction with synthetic data. Never post credentials or private messages. Test changes in a separate guild before deployment.
