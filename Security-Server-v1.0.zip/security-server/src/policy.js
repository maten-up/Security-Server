export function windowPush(old, now, ms, max) {
  return [...old.filter(t => t > now-ms), now].slice(-max);
}
export function assess(i) {
  const flags=[];
  if(i.count>=i.limit) flags.push('message-flood');
  if(i.repeat>=i.repeatLimit) flags.push('duplicate-spam');
  if(i.mentions>=i.mentionLimit||i.everyone) flags.push('mention-flood');
  for(const raw of i.text.match(/https?:\/\/[^\s<>]+/gi)||[]) {
    try {
      const u=new URL(raw), h=u.hostname.toLowerCase().replace(/\.$/,'');
      if(i.blockInvite&&(h==='discord.gg'||h==='www.discord.gg'||(['discord.com','www.discord.com','discordapp.com','www.discordapp.com'].includes(h)&&u.pathname.startsWith('/invite/')))&&!flags.includes('external-invite')) flags.push('external-invite');
      if(i.blockedHosts.some(d=>h===d||h.endsWith('.'+d))&&!flags.includes('blocked-domain')) flags.push('blocked-domain');
    } catch { /* malformed URL */ }
  }
  return flags;
}
