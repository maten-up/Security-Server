import test from 'node:test';
import assert from 'node:assert/strict';
import {assess,windowPush} from '../src/policy.js';
const base={count:1,limit:6,repeat:1,repeatLimit:4,mentions:0,mentionLimit:5,everyone:false,blockInvite:false,text:'hello',blockedHosts:['bad.example']};
const cases=[[{},[]],[{count:6},['message-flood']],[{repeat:4},['duplicate-spam']],[{mentions:5},['mention-flood']],[{everyone:true},['mention-flood']],[{text:'https://sub.bad.example/x'},['blocked-domain']],[{text:'https://bad.example.safe.example'},[]],[{blockInvite:true,text:'https://discord.gg/test'},['external-invite']],[{blockInvite:false,text:'https://discord.gg/test'},[]],[{blockInvite:true,text:'https://discord.gg.safe.example/test'},[]],[{text:'https://bad.example@safe.example'},[]]];
for(const [i,[input,expected]] of cases.entries())test('policy '+i,()=>assert.deepEqual(assess({...base,...input}),expected));
test('rolling window',()=>assert.deepEqual(windowPush([1,90],100,20,3),[90,100]));
test('bounded window',()=>assert.deepEqual(windowPush([91,92,93],100,20,2),[93,100]));
