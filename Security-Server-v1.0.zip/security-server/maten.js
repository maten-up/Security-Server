import {Client, GatewayIntentBits, PermissionFlagsBits, Events, SlashCommandBuilder, EmbedBuilder, MessageFlags} from 'discord.js';
import {mkdir, appendFile, stat, rename} from 'node:fs/promises';
import {spawn} from 'node:child_process';
import {createHash} from 'node:crypto';
import {assess,windowPush} from './src/policy.js';
const env=process.env;
const snow=v=>/^\d{17,20}$/.test(v||'');
if(!env.DISCORD_TOKEN||!snow(env.GUILD_ID)||!snow(env.LOG_CHANNEL_ID)) throw Error('Configure DISCORD_TOKEN, GUILD_ID and LOG_CHANNEL_ID');
const bounded=(name,def,min,max)=>{const x=Number(env[name]||def);if(!Number.isInteger(x)||x<min||x>max)throw Error('Invalid '+name);return x;};
const config={mode:env.MODE||'observe',limit:bounded('MESSAGE_LIMIT',6,3,30),repeatLimit:bounded('REPEAT_LIMIT',4,3,20),mentionLimit:bounded('MENTION_LIMIT',5,2,30),joinLimit:bounded('JOIN_LIMIT',8,3,100),blockInvite:env.BLOCK_INVITES==='true',blockedHosts:(env.BLOCKED_HOSTS||'').split(',').map(s=>s.trim().toLowerCase()).filter(Boolean),exempt:new Set((env.EXEMPT_ROLE_IDS||'').split(',').map(s=>s.trim()).filter(snow))};
if(!['observe','enforce'].includes(config.mode)) throw Error('Invalid MODE');
if(config.blockedHosts.some(h=>!/^[a-z0-9.-]+$/.test(h))) throw Error('BLOCKED_HOSTS accepts hostnames only');
const client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent],allowedMentions:{parse:[]}});
const file='data/events.jsonl', recent=new Map(), cooldown=new Map();
let joins=[],raidUntil=0,logQueue=Promise.resolve(),lastAlert=0,pending=0,reportRunning=false;
await mkdir('data',{recursive:true,mode:0o700});
function fail(label,e){console.error(label,String(e?.code||e?.name||'error'));}
function record(event){
 if(pending>=1000){console.error('Audit queue full');return Promise.resolve();}
 pending++;
 logQueue=logQueue.then(async()=>{
  const size=await stat(file).then(s=>s.size).catch(e=>{if(e.code==='ENOENT')return 0;throw e;});
  if(size>5*1024*1024)await rename(file,file+'.1');
  await appendFile(file,JSON.stringify({time:new Date().toISOString(),...event})+'\n',{mode:0o600});
 }).catch(e=>fail('Audit',e)).finally(()=>pending--);
 return logQueue;
}
async function alert(guild,event,memberId){
 await record(event);
 if(Date.now()-lastAlert<1000)return;
 lastAlert=Date.now();
 const channel=await guild.channels.fetch(env.LOG_CHANNEL_ID).catch(()=>null);
 if(!channel?.isSendable())return;
 const embed=new EmbedBuilder().setColor(0xd97706).setTitle('Security alert').addFields({name:'Event',value:event.kind},{name:'Indicators',value:event.flags.join(', ')||'None'},{name:'Action',value:event.action}).setTimestamp();
 if(memberId)embed.addFields({name:'Member ID',value:memberId});
 await channel.send({embeds:[embed],allowedMentions:{parse:[]}}).catch(e=>fail('Alert',e));
}
function exempt(m){return !m||m.id===m.guild.ownerId||m.permissions.has(PermissionFlagsBits.ManageMessages)||m.permissions.has(PermissionFlagsBits.ModerateMembers)||m.roles.cache.some(r=>config.exempt.has(r.id));}
const commands=[new SlashCommandBuilder().setName('security-status').setDescription('Show security policy'),new SlashCommandBuilder().setName('security-report').setDescription('Summarize incidents using Python')].map(x=>x.setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild));
function pythonReport(){return new Promise((resolve,reject)=>{
 const p=spawn(env.PYTHON_BIN||'python3',['python/report.py',file],{shell:false,windowsHide:true,stdio:['ignore','pipe','ignore'],env:{...process.env,DISCORD_TOKEN:''}});
 let output='',done=false;
 const finish=(err,v)=>{if(done)return;done=true;clearTimeout(timer);err?reject(err):resolve(v);};
 const timer=setTimeout(()=>{p.kill();finish(Error('Report timeout'));},8000);
 p.stdout.on('data',b=>{output+=b.toString();if(output.length>16000){p.kill();finish(Error('Report too large'));}});
 p.on('error',e=>finish(e));p.on('close',code=>finish(code===0?null:Error('Report failed'),output));
});}
client.once(Events.ClientReady,async c=>{
 try{const guild=await c.guilds.fetch(env.GUILD_ID),channel=await guild.channels.fetch(env.LOG_CHANNEL_ID);
 if(!channel?.isSendable())throw Error('Invalid log channel');
 const existing=await guild.commands.fetch();
 for(const command of commands){const old=existing.find(x=>x.name===command.name);if(old)await guild.commands.edit(old.id,command.toJSON());else await guild.commands.create(command.toJSON());}
 console.log('Security-Server ready: '+config.mode);
 }catch(e){fail('Startup',e);client.destroy();process.exitCode=1;}
});
client.on(Events.MessageCreate,m=>{void(async()=>{
 if(m.guildId!==env.GUILD_ID||m.author.bot||m.webhookId||exempt(m.member))return;
 const now=Date.now(),key=m.author.id;
 if(!recent.has(key)&&recent.size>=10000)return;
 const item=recent.get(key)||{times:[],same:[],hash:'',last:now,alert:0};
 const hash=m.content.trim()?createHash('sha256').update(m.content.trim().toLowerCase()).digest('hex'):'';
 item.times=windowPush(item.times,now,10000,30);
 item.same=hash&&hash===item.hash?windowPush(item.same,now,30000,20):[now];item.hash=hash;item.last=now;recent.set(key,item);
 const flags=assess({...config,count:item.times.length,repeat:hash?item.same.length:0,mentions:m.mentions.users.size+m.mentions.roles.size,everyone:m.mentions.everyone,text:m.content});
 if(!flags.length)return;
 let action='observed';const flood=flags.some(x=>['message-flood','duplicate-spam','mention-flood'].includes(x));
 if(config.mode==='enforce'){
  if(m.deletable){try{await m.delete();action='deleted';}catch(e){fail('Delete',e);action='delete-failed';}}
  if(flood&&m.member?.moderatable&&now-(cooldown.get(key)||0)>60000){cooldown.set(key,now);try{await m.member.timeout(60000,'Security-Server: '+flags.join(', '));action+='+timeout';}catch(e){fail('Timeout',e);action+='+timeout-failed';}}
 }
 if(now-item.alert>10000){item.alert=now;await alert(m.guild,{kind:'message-risk',flags,action},key);}
})().catch(e=>fail('Message',e));});
client.on(Events.GuildMemberAdd,m=>{void(async()=>{
 if(m.guild.id!==env.GUILD_ID||m.user.bot)return;
 const now=Date.now();joins=windowPush(joins,now,15000,100);
 if(joins.length>=config.joinLimit&&now>raidUntil){raidUntil=now+60000;await alert(m.guild,{kind:'join-surge',flags:['raid-indicator'],action:'alert-only'});}
 if(now-m.user.createdTimestamp<86400000)await alert(m.guild,{kind:'new-account',flags:['account-under-24h'],action:'alert-only'},m.id);
})().catch(e=>fail('Join',e));});
client.on(Events.InteractionCreate,i=>{void(async()=>{
 if(!i.isChatInputCommand()||i.guildId!==env.GUILD_ID||!['security-status','security-report'].includes(i.commandName))return;
 const reply=content=>i.reply({content,flags:MessageFlags.Ephemeral});
 if(!i.memberPermissions?.has(PermissionFlagsBits.ManageGuild)){await reply('Manage Server required.');return;}
 if(i.commandName==='security-status'){await reply('Mode: '+config.mode+' | Raid indicator: '+(Date.now()<raidUntil?'active':'normal')+' | Spam: '+config.limit+'/10s');return;}
 if(reportRunning){await reply('Report already running.');return;}
 reportRunning=true;
 try{await i.deferReply({flags:MessageFlags.Ephemeral});await logQueue;await i.editReply({content:(await pythonReport()).slice(0,1900),allowedMentions:{parse:[]}});}catch(e){fail('Report',e);if(i.deferred)await i.editReply('Report unavailable. Check Python setup.').catch(()=>{});}finally{reportRunning=false;}
})().catch(e=>fail('Interaction',e));});
const sweep=setInterval(()=>{const now=Date.now();for(const [id,v] of recent)if(now-v.last>60000)recent.delete(id);for(const [id,t] of cooldown)if(now-t>60000)cooldown.delete(id);},30000);sweep.unref();
client.on(Events.Error,e=>fail('Discord',e));
for(const sig of ['SIGINT','SIGTERM'])process.once(sig,()=>{clearInterval(sweep);client.destroy();void logQueue.then(()=>{process.exit(0);});});
await client.login(env.DISCORD_TOKEN);
