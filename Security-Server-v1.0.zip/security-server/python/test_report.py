import json
import tempfile
import unittest
from datetime import datetime, timezone, timedelta
from pathlib import Path
from report import summarize

class ReportTests(unittest.TestCase):
    def test_filter(self):
        now=datetime(2026,1,1,tzinfo=timezone.utc)
        with tempfile.TemporaryDirectory() as tmp:
            p=Path(tmp)/'events.jsonl'
            def event(when):
                return json.dumps({'time':when.isoformat(),'kind':'message-risk','action':'observed','flags':['spam']})
            p.write_text('\n'.join([event(now),event(now-timedelta(days=2)),event(now+timedelta(hours=1)),'invalid']))
            r=summarize([p],now)
            self.assertEqual(r['events'],1)
            self.assertEqual(r['flags'],{'spam':1})
            self.assertEqual(r['invalid'],1)
    def test_missing(self):
        with tempfile.TemporaryDirectory() as tmp:
            self.assertEqual(summarize([Path(tmp)/'missing'])['events'],0)
